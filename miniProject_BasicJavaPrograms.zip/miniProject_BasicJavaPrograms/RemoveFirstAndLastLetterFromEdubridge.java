package miniProject_BasicJavaPrograms;

public class RemoveFirstAndLastLetterFromEdubridge 
{

	public static void main(String[] args)
	{
		        String input = "Edubridge";
		        
		        if (input.length() >= 2) 
		        {
		            String result = input.substring(1, input.length() - 1);
		            System.out.println("Original: " + input);
		            System.out.println("Modified: " + result);
		        } 
		        else 
		        {
		            System.out.println("The input is too short to remove first and last letters.");
		        }
	 }
}


