package miniProject_BasicJavaPrograms;
import java.util.Arrays;
public class RemoveArrayElements {

	public static void main(String[] args)
	{
		        int[] array = {1, 3, 4, 5, 6, 7, 8, 9, 10};
		        
		        if (array.length < 6) 
		        {
		            System.out.println("Array doesn't have enough elements to remove the 5th and 6th elements.");
		            return;
		        }
		        
		        int[] newArray = removeElements(array, 4, 5); // Indices start from 0
		        
		        System.out.println("Original array: " + Arrays.toString(array));
		        System.out.println("Array after removing 5th and 6th elements: " + Arrays.toString(newArray));
		    }
		    
		    public static int[] removeElements(int[] array, int index1, int index2) 
		    {
		        if (index1 < 0 || index1 >= array.length || index2 < 0 || index2 >= array.length)
		        {
		            return array; // Return the original array if indices are out of bounds
		        }
		        
		        int newSize = array.length - 2; // New size after removing two elements
		        int[] newArray = new int[newSize];
		        
		        for (int i = 0, j = 0; i < array.length; i++) 
		        {
		            if (i != index1 && i != index2) 
		            {
		                newArray[j++] = array[i];
		            }
		        }
		        
		        return newArray;
		    }
		}
