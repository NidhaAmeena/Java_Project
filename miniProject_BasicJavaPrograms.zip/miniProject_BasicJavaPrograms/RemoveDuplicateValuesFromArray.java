package miniProject_BasicJavaPrograms;
import java.util.Arrays;
import java.util.LinkedHashSet;

public class RemoveDuplicateValuesFromArray 
{
	public static void main(String[] args) 
	{
		int[] array = {1, 2, 2, 3, 4, 4, 5, 6, 6, 7};

        // Convert array to LinkedHashSet to remove duplicates
        LinkedHashSet<Integer> set = new LinkedHashSet<>();
        for (int num : array) 
        {
            set.add(num);
        }

        // Convert set back to array
        int[] newArray = new int[set.size()];
        int index = 0;
        for (int num : set) {
            newArray[index++] = num;
        }

        System.out.println("Original array: " + Arrays.toString(array));
        System.out.println("Array after removing duplicates: " + Arrays.toString(newArray));
    }
}
