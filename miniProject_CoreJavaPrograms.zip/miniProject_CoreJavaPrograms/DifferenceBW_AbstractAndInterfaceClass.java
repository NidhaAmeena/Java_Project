package miniProject_CoreJavaPrograms;

//Abstract class
abstract class AbstractShape 
{
	abstract void draw(); // Abstract method
	void display()
	{
     System.out.println("Displaying shape.");
	}
}

//Interface
interface Drawable
{
	void draw(); // Method declaration, no implementation
	default void display()
	{
     System.out.println("Displaying drawable.");
	}
}

//Concrete class implementing abstract class and interface
class Circle extends AbstractShape implements Drawable 
{
	@Override
 	public void draw() 
 	{
     System.out.println("Drawing a circle.");
 	}
 
 	@Override
 	public void display() 
 	{
     System.out.println("Displaying a circle.");
 	}
}


public class DifferenceBW_AbstractAndInterfaceClass 
{
	 public static void main(String[] args)
	 {
	     Circle circle = new Circle();
	     circle.draw();     // Calls draw() from Circle class
	     circle.display();  // Calls display() from Circle class
	     
	     // Using polymorphism
	     AbstractShape abstractShape = new Circle();
	     abstractShape.draw();    // Calls draw() from Circle class
	     abstractShape.display(); // Calls display() from Circle class
	     
	     Drawable drawable = new Circle();
	     drawable.draw();        // Calls draw() from Circle class
	     drawable.display();     // Calls display() from Drawable interface
	 }
}


