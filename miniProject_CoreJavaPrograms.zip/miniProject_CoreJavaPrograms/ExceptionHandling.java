package miniProject_CoreJavaPrograms;
import java.util.Scanner;

public class ExceptionHandling 
{
	public static void main(String[] args) 
	{
		        Scanner scanner = new Scanner(System.in);

		        // Example 1: Using try-catch block
		        try {
		            System.out.print("Enter a number: ");
		            int num = Integer.parseInt(scanner.nextLine());
		            int result = 10 / num;
		            System.out.println("Result: " + result);
		        } 
		        catch (ArithmeticException e)
		        {
		            System.out.println("ArithmeticException: " + e.getMessage());
		        } 
		        catch (NumberFormatException e) 
		        {
		            System.out.println("NumberFormatException: " + e.getMessage());
		        } 
		        catch (Exception e) 
		        {
		            System.out.println("General Exception: " + e.getMessage());
		        }

		        // Example 2: Using try-catch-finally block
		        int[] array = {1, 2, 3};
		        try
		        {
		            System.out.print("Enter an index: ");
		            int index = Integer.parseInt(scanner.nextLine());
		            System.out.println("Value at index " + index + ": " + array[index]);
		        } 
		        catch (ArrayIndexOutOfBoundsException e)
		        {
		            System.out.println("ArrayIndexOutOfBoundsException: " + e.getMessage());
		        } 
		        finally 
		        {
		            System.out.println("Finally block always executes.");
		        }

		        // Example 3: Using throws keyword
		        try
		        {
		            performDivision(20, 0);
		        } 
		        catch (ArithmeticException e)
		        {
		            System.out.println("ArithmeticException: " + e.getMessage());
		        }

		        // Example 4: Using custom exception
		        try 
		        {
		            withdrawMoney(1000, 2000);
		        } 
		        catch (InsufficientFundsException e)
		        {
		            System.out.println("InsufficientFundsException: " + e.getMessage());
		        }

		        scanner.close();
		    }

		    // Example 3: Using throws keyword to delegate exception handling
		    static void performDivision(int numerator, int denominator) throws ArithmeticException
		    {
		        int result = numerator / denominator;
		        System.out.println("Result: " + result);
		    }

		    // Example 4: Custom exception class
		    static void withdrawMoney(double balance, double amount) throws InsufficientFundsException 
		    {
		        if (amount > balance) 
		        {
		            throw new InsufficientFundsException("Insufficient funds in the account.");
		        } 
		        else 
		        {
		            System.out.println("Withdrawal successful. Remaining balance: " + (balance - amount));
		        }
		    }
		}

		// Custom exception class
		class InsufficientFundsException extends Exception 
		{
		    public InsufficientFundsException(String message) 
		    {
		        super(message);
		    }
		}


