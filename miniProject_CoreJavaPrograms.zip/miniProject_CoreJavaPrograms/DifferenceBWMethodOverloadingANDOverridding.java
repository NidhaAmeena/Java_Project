package miniProject_CoreJavaPrograms;

class Parent {
    void show() {
        System.out.println("This is the parent class.");
    }
    
    void show(int num) {
        System.out.println("Parent class with int parameter: " + num);
    }
}

class Child extends Parent 
{
    @Override
    void show() 
    {
        System.out.println("This is the child class.");
    }
    
    void show(String message) 
    {
        System.out.println("Child class with string parameter: " + message);
    }

}

public class DifferenceBWMethodOverloadingANDOverridding 
{
	public static void main(String[] args) 
	{
        Parent parent = new Parent();
        parent.show();          // Calls parent's show()
        parent.show(10);        // Calls parent's show(int)

        Child child = new Child();
        child.show();           // Calls child's overridden show()
        child.show("Hello");    // Calls child's show(String)
		

		}

	}
