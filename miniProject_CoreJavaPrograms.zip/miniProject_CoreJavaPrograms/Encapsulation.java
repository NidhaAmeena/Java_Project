package miniProject_CoreJavaPrograms;

class Person
{
    private String name;
    private int age;

    public Person(String name, int age) 
    {
        this.name = name;
        this.age = age;
    }

    // Getter methods for encapsulation
    public String getName()
    {
        return name;
    }

    public int getAge()
    {
        return age;
    }
}

class Employee extends Person
{
    private double salary;

    public Employee(String name, int age, double salary)
    {
        super(name, age);
        this.salary = salary;
    }

    public double getSalary() 
    {
        return salary;
    }
}

public class Encapsulation {

	public static void main(String[] args) 
	{
		 Employee employee = new Employee("Alice", 30, 50000.0);
	        
	        System.out.println("Employee Name: " + employee.getName());
	        System.out.println("Employee Age: " + employee.getAge());
	        System.out.println("Employee Salary: $" + employee.getSalary());
	}

}
